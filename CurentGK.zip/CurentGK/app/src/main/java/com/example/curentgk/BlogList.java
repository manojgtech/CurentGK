package com.example.curentgk;

import android.content.Intent;
import android.graphics.ColorSpace;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BlogList extends AppCompatActivity {
    private static final String JSON_URL = "https://www.googleapis.com/blogger/v2/blogs/6358489634201359297/posts?key=AIzaSyBcj47Z7O351gLSd3t2vQPG1iiXQVwvbMU";

    //listview object
    ListView listView;

    //the hero list where we will store all the hero objects after parsing json
    List<Blog> blogList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blog_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);




       listView = findViewById(R.id.bloglist);
        blogList = new ArrayList<>();

        //this method will fetch and parse the data
       loadHeroList();

       listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
           public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Blog row =  blogList.get(position);
             String  postID = row.getPostId();

               Toast.makeText(getApplicationContext(), row.getPostId(), Toast.LENGTH_LONG).show();
               Intent blogin=new Intent(BlogList.this,Blogpost.class);
               blogin.putExtra("postid", postID);
               startActivity(blogin);
           }
       });
    }

    private  void loadHeroList(){
        final ProgressBar progressBar = (ProgressBar) findViewById(R.id.nprogbar);

        //making the progressbar visible
        progressBar.setVisibility(View.VISIBLE);

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.GET, JSON_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completion
                        progressBar.setVisibility(View.INVISIBLE);


                        try {
                            //getting the whole json object from the response
                            JSONObject obj = new JSONObject(response);

                            //we have the array named hero inside the object
                            //so here we are getting that json array
                            JSONArray heroArray = obj.getJSONArray("items");
                            Log.d("JSONARR", heroArray.toString());

                            //Toast.makeText(getApplicationContext(), heroArray.toString(), Toast.LENGTH_LONG).show();

                            //now looping through all the elements of the json array
                           for (int i = 0; i < heroArray.length(); i++) {
                                //getting the json object of the particular index inside the array
                                JSONObject heroObject = heroArray.getJSONObject(i);
                                Log.d("JSONob", heroObject.toString());

                                //creating a hero object and giving them the values from json object
                                Blog hero = new Blog(heroObject.getString("title"),heroObject.getString("id"));

                                //adding the hero to herolist
                               blogList.add(hero);
                            }

                            //creating custom adapter object
                           ListViewAdapter adapter = new ListViewAdapter(blogList, getApplicationContext());

                            //adding the adapter to listview
                            listView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }
}
